from tests.test_spotify import TestSpotify
from tests.test_yelp import TestYelp
from tests.test_authentication import TestAuthentication
import unittest
import helpers
helpers.modify_system_path()


if __name__ == '__main__':
    unittest.main()
