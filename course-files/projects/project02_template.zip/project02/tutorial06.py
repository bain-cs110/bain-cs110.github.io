from apis import spotify

results = spotify.get_artists("Beyoncé")

for artist in results:
    print(artist['name'], artist['id'])
