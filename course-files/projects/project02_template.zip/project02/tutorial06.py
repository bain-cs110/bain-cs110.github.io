from apis import spotify

artists = spotify.get_artists("Beyonce")

for artist in artists:
    if artist.get('genres'):
        print(artist['genres'])
    else:
        print("no genre")

print(spotify.get_formatted_artist_table_html(artists))
