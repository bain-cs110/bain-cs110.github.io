from apis import spotify
from apis import twilio

results = spotify.get_similar_tracks(genres=['chill', 'blues'])
print(results)
