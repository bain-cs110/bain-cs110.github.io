bill = 13.00
tip = 20 # percentage points

x = tip / 100 * bill

bill = bill + x

y = str(x)

print("Your tip amount is:" + y)
print("Your total is:" + bill)
