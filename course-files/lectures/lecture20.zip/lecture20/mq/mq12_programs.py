pizza = "hello"
if len(pizza) > 3:
    result = True
else:
    result = 13.0






















a = 6
if a < 6:
    print('Lexus')
elif a <= 6:    
    print('Honda')
else:    
    print('Tesla')


