# ----------------------------------------------------
# 1. say hello using an input
# ----------------------------------------------------
print("Hello there, Obi-wan!")
print("Your name is", len("Obi-wan"), "letters long")
print("How are you this morning?")