# Challenge:
#   1. How many unique letters are in the word supercalifragilisticexpialidocious?
#   2. How many times does each letter occur?

word = 'supercalifragilisticexpialidocious'
