f = open('my_new_file.txt', 'w')

f.write('hello world!')
f.close()