f = open('moby_dick.txt', 'r')

# Your job: can you write some code to
# count how many lines there are in the file?

# print('there are ', ?????, 'lines in the file.')