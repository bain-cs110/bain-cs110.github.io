##### Examples of Writing your Own Reporter Functions

# Calculate the area of a square
height = 15
area = height * height
print(area)
