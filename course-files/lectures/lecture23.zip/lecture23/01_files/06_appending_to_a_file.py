f = open('my_new_file.txt', 'a')

f.write('\nthis is another line. It will append to my_file.txt')
f.close()