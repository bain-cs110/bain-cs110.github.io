f = open('moby_dick.txt', 'r')

for line in f:
    print(line)
f.close()