names = ['Connor Bain', 'Shameik Moore', 'Kimiko Glenn', 'Tom Holland', 'Andrew Garfield', 'Tobey Maguire', 'Hailee Steinfeld']

# write a while loop that prints every item in the names list:
