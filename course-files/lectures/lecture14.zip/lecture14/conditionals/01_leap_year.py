def print_days_in_february(year):
    print('...')
    print('February 26')
    print('February 27')
    print('February 28')
    if year % 4 == 0:
        print('February 29')

print_days_in_february(2019)
print_days_in_february(2020)