names = ['Shameik Moore', 'Kimiko Glenn', 'Tom Holland', 'Andrew Garfield', 'Tobey Maguire', 'Hailee Steinfeld']

# write a while loop that prints every item in the names list:
counter = 0
while counter < len(names):
     print(names[counter])
     counter = counter + 1
