counter = 0
while counter < 10:
    print('Hey there! Hope you\'re doing OK!')
    counter = counter + 1
