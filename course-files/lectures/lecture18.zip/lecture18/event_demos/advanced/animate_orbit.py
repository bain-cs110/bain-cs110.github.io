'''
Documentation:
  * tkinter events: https://www.python-course.eu/tkinter_events_binds.php
  * Canvas: https://anzeljg.github.io/rin2/book2/2405/docs/tkinter/canvas.html
  * Other Canvas methods: https://anzeljg.github.io/rin2/book2/2405/docs/tkinter/canvas-methods.html
'''
from tkinter import Canvas, Tk
from p1_utilities import update_position, make_circle, make_car
import math
import time

gui = Tk()
gui.title('Orbit Example')
canvas = Canvas(gui, width=500, height=500, background='white')
canvas.pack()
########################## YOUR CODE BELOW THIS LINE ##############################

# Uses some basic math to calculate the (x,y) positions that would represent one
# shape orbiting around another shape

center_x = 200
center_y = 200
distance_from_center = 120
center = (center_x, center_y)
center_creature = (center_x, center_y - distance_from_center)

make_car(canvas, center_creature, fill_color='hotpink', my_tag='creature')
make_circle(canvas, center, 10, fill_color='black')

counter = 0
slow_factor = 250

while True:
    # calculate new position of x and y
    radians = counter / slow_factor
    dy = distance_from_center / slow_factor * math.sin(radians)
    dx = distance_from_center / slow_factor * math.cos(radians)
    update_position(canvas, tag='creature', x=dx, y=dy)
    counter += 1
    gui.update()
    time.sleep(.01)
