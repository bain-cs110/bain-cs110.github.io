from cs110_l8 import *
_ignore = setup_shapes('Lecture 8', background="white", width=600, height=600)
########################## YOUR CODE BELOW THIS LINE ##############################

## rectangle: A function that creates rectangles!
## def rectangle(center_x, center_y, width, height, color="hotpink"):
##     ...




########################## YOUR CODE ABOVE THIS LINE ##############################
_ignore.mainloop()