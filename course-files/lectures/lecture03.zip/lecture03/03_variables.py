########################
# Variables #
########################

## Assigning variables
test_1 = "I'm a string" # a string
test_2 = 1234 # an int
test_3 = 1.05 # a float

print(type(test_1))
print(type(test_2))
print(type(test_3))

## Accessing variables
side_length = 5.0
area_of_a_square = side_length * side_length
print(area_of_a_square)

my_name = "connor"
print("hello," + my_name)

## Updating Variables
x = 13
y = 7
x = x + y
print(x)
x = 100
print(x)
