from cs110_t3_shapes import *
_ignore = setup_shapes('Tutorial 3', background="white", width=800, height=800)
#### YOUR CODE BELOW THIS LINE ##########

## Reporter and Sequence Practice goes here



### End Reporter and Sequence Practice

## Flag of Chicago Challenge!






#### IGNORE BELOW
_ignore.mainloop()