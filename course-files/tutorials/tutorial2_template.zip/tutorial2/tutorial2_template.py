from cs110_t2 import *
_ignore = setup_shapes('Tutorial 2', background="white", width=600, height=600)
#### IGNORE THE ABOVE







#### IGNORE BELOW
_ignore.mainloop()