from cs110_hw2 import *
_ignore = setup_shapes('HW 2', background="white", width=500, height=500)
#### IGNORE THE ABOVE



## TASK 1 



## TASK 2



## TASK 3



## TASK 4





##### IGNORE THE BELOW
_ignore.mainloop()