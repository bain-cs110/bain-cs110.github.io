from tkinter import Canvas, Tk
import time
from utilities import make_grid

# initialize window
gui = Tk()
the_canvas = Canvas(gui, width=600, height=600, background='white',
                    scrollregion="0 -600 600 0")
the_canvas.pack()

# helper function that draws a grid.
make_grid(the_canvas, 600, 600)
########################## YOUR CODE BELOW THIS LINE ##############################

def make_square(a_canvas, bottom_left, width, fill_color='#84A9C0', outline_color='#DDD', tag=None):
    a_canvas.create_rectangle([
        bottom_left,
        (bottom_left[0] + width, bottom_left[1] + width)
        ],
        fill=fill_color,
        outline=outline_color,
        tags=tag
    )
    a_canvas.scale(tag, 0, 0, 1, -1)

# Ask python to start a counter
counter = 0

width = 50
# Infinitely loop
while True:

    # Delete the existing shape on the screen
    the_canvas.delete("my_shape")
    the_canvas.delete("my_shape_2")

    # Each step, we draw a different colored square in a cycle of 1, 2, 3
    if counter % 3 == 0:
       make_square(the_canvas, (counter * 5, 100), width, fill_color="red", tag="my_shape")
       make_square(the_canvas, (counter * 5 + 100, 200), width, fill_color="red", tag="my_shape_2")

    elif counter % 3 == 1:
        make_square(the_canvas, (counter * 5, 100), width, fill_color="yellow", tag="my_shape")
        make_square(the_canvas, (counter * 5 + 100, 200), width, fill_color="yellow", tag="my_shape_2")
        
    else:
        make_square(the_canvas, (counter * 5, 100), width, fill_color="blue", tag="my_shape")
        make_square(the_canvas, (counter * 5 + 100, 200), width, fill_color="blue", tag="my_shape_2")

    # Ask Python to add one to the counter
    counter += 1

    # Ask TKinter to update our drawing
    gui.update()

    # Pause for a moment
    time.sleep(0.25)

########################## YOUR CODE ABOVE THIS LINE ##############################
the_canvas.mainloop()
